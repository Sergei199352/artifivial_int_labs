package aips.lab02.mcSolution;

/**
 * This enumerated type defined the 2 values that represent the 2 river banks.
 * @author kit
 *
 */
public enum RiverBank {
NORTH,SOUTH;
} //end enum
